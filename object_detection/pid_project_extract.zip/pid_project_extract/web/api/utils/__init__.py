"""API for checking project status."""
from pid_project_extract.web.api.utils.utils import router

__all__ = ['router']
