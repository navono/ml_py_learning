"""API for checking project status."""
from pid_project_extract.web.api.monitoring.views import router

__all__ = ['router']
