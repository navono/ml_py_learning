"""Tests for pid_project_extract."""
